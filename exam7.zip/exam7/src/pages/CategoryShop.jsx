const CategoryShop = () => {
    return (
      <div className="linkss">
        <a href="/blush" className="linkkk">BLUSH</a>
        <a href="/bronzer" className="linkkk">BRONZER</a>
        <a href="/eyebrow" className="linkkk">EYEBROW</a>
        <a href="/eyeliner" className="linkkk">EYELINER</a>
        <a href="/eyeshadow" className="linkkk">EYESHADOW</a>
      </div>
    );
}

export default CategoryShop;