const CategoryRoutine = () => {
    return (
      <div className="linkss">
        <a href="/foundation" className="linkkk">FOUNDATION</a>
        <a href="/lip_liner" className="linkkk">LIP LINER</a>
        <a href="/lip_stick" className="linkkk">LIP STICK</a>
        <a href="/mascara" className="linkkk">MASCARA</a>
        <a href="/nail_polish" className="linkkk">NAIL POLISH</a>
      </div>
    );
}

export default CategoryRoutine;